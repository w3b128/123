class ArticlesController < ApplicationController
  def new
  end
end
